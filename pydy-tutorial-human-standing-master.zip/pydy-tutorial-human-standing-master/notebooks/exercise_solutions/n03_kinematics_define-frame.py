upper_leg_frame = ReferenceFrame('U')
torso_frame = ReferenceFrame('T')