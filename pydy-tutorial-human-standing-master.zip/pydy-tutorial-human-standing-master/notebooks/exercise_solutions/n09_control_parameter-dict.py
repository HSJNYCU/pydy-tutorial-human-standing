parameter_dict = dict(zip(constants, numerical_constants))
parameter_dict
