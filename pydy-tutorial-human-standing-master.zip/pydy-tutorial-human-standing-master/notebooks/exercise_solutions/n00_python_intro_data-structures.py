num_list = [1,2,3,4]

months = ['Jan', 'Feb', 'Mar', 'Apr']

months_dict = dict(zip(months, num_list))