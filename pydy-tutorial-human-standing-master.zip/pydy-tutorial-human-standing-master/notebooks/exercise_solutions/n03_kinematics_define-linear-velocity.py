hip.v2pt_theory(knee, inertial_frame, upper_leg_frame)
hip.vel(inertial_frame)

torso_mass_center.v2pt_theory(hip, inertial_frame, torso_frame)
torso_mass_center.vel(inertial_frame)